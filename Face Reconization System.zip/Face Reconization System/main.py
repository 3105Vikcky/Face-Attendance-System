from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from student import Student
import os
from tkinter import messagebox
import mysql.connector
import cv2
import numpy as np
from face_recognition import Face_recognition
from attendance import Attendance

class Face_Recognisation_System:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1280x600+0+0")    #1280 X 600 is screen resolution and for start from corner used 0+0
        self.root.title("Face Recognization System")
        #First Image
        img=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\FACE2.jpg")
        img=img.resize((426,130),Image.LANCZOS)
        self.photoimg=ImageTk.PhotoImage(img)

        f_lbl=Label(self.root,image=self.photoimg)
        f_lbl.place(x=0,y=0,width=426,height=130)

        #Second Image
        img1=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\FACE2.jpg")
        img1=img1.resize((426,130),Image.LANCZOS)
        self.photoimg1=ImageTk.PhotoImage(img1)

        f_lbl=Label(self.root,image=self.photoimg1)
        f_lbl.place(x=426,y=0,width=426,height=130)

        #Third Image
        img2=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\FACE2.jpg")
        img2=img2.resize((426,130),Image.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(img2)

        f_lbl=Label(self.root,image=self.photoimg2)
        f_lbl.place(x=852,y=0,width=426,height=130)

        #Background Image
        img3=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\Background.jpg")
        img3=img3.resize((1280,600),Image.LANCZOS)
        self.photoimg3=ImageTk.PhotoImage(img3)

        bg_img=Label(self.root,image=self.photoimg3)
        bg_img.place(x=0,y=130,width=1280,height=470)

        #Set title name and place
        title_lb1=Label(bg_img,text="FACE RECOGNITION ATTENDANCE",font=("times new roman",35,"bold"),bg="green",fg="orange")
        title_lb1.place(x=0,y=0,width=1280,height=35)

        #Student Button 
        img4=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\student-button.jpg")
        img4=img4.resize((150,150),Image.LANCZOS)
        self.photoimg4=ImageTk.PhotoImage(img4)

        b1=Button(bg_img,image=self.photoimg4,command=self.login,cursor="hand2")
        b1.place(x=80,y=60,width=150,height=150)

        b1=Button(bg_img,text="Student Details",command=self.login,cursor="hand2",font=("times new roman",12,"bold"),bg="darkblue",fg="white")
        b1.place(x=80,y=200,width=150,height=25)


         #Detect Face Button 
        img5=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\detect-face.jpg")
        img5=img5.resize((150,150),Image.LANCZOS)
        self.photoimg5=ImageTk.PhotoImage(img5)

        b1=Button(bg_img,image=self.photoimg5,cursor="hand2",command=self.face_data)
        b1.place(x=350,y=60,width=150,height=150)

        b1=Button(bg_img,text="Face Detector",cursor="hand2",command=self.face_data,font=("times new roman",12,"bold"),bg="darkblue",fg="white")
        b1.place(x=350,y=200,width=150,height=25)



        #Attendance Button 
        img6=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\Attendance-button.jpg")
        img6=img6.resize((150,150),Image.LANCZOS)
        self.photoimg6=ImageTk.PhotoImage(img6)

        b1=Button(bg_img,image=self.photoimg6,cursor="hand2",command=self.show_Attendance1)
        b1.place(x=620,y=60,width=150,height=150)

        b1=Button(bg_img,text="Attendance",cursor="hand2",command=self.show_Attendance1,font=("times new roman",12,"bold"),bg="darkblue",fg="white")
        b1.place(x=620,y=200,width=150,height=25)


        #Help Button 
        img7=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\help-button.jpg")
        img7=img7.resize((150,150),Image.LANCZOS)
        self.photoimg7=ImageTk.PhotoImage(img7)

        b1=Button(bg_img,image=self.photoimg7,cursor="hand2",command=self.show_help)
        b1.place(x=890,y=60,width=150,height=150)

        b1=Button(bg_img,text="Help",cursor="hand2",command=self.show_help,font=("times new roman",12,"bold"),bg="darkblue",fg="white")
        b1.place(x=890,y=200,width=150,height=25)


         #Train images Button 
        img8=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\train-button.png")
        img8=img8.resize((150,150),Image.LANCZOS)
        self.photoimg8=ImageTk.PhotoImage(img8)

        b1=Button(bg_img,image=self.photoimg8,cursor="hand2",command=self.train_classifier)
        b1.place(x=80,y=300,width=150,height=150)

        b1=Button(bg_img,text="Train Face",cursor="hand2",command=self.train_classifier,font=("times new roman",12,"bold"),bg="darkblue",fg="white")
        b1.place(x=80,y=425,width=150,height=25)


        #Photos Button 
        img9=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\photo-button.jpg")
        img9=img9.resize((150,150),Image.LANCZOS)
        self.photoimg9=ImageTk.PhotoImage(img9)

        b1=Button(bg_img,image=self.photoimg9,cursor="hand2",command=self.open_img)
        b1.place(x=350,y=300,width=150,height=150)

        b1=Button(bg_img,text="Photos",cursor="hand2",command=self.open_img,font=("times new roman",12,"bold"),bg="darkblue",fg="white")
        b1.place(x=350,y=425,width=150,height=25)


        #Exit  Button 
        img10=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\exit-button.jpg")
        img10=img10.resize((150,150),Image.LANCZOS)
        self.photoimg10=ImageTk.PhotoImage(img10)

        b1=Button(bg_img,image=self.photoimg10,cursor="hand2",command=self.exit_application)
        b1.place(x=890,y=300,width=150,height=150)

        b1=Button(bg_img,text="Exit",cursor="hand2",command=self.exit_application,font=("times new roman",12,"bold"),bg="darkblue",fg="white")
        b1.place(x=890,y=425,width=150,height=25)
        #=====================open Images=====================
    def open_img(self):
        os.startfile("data")
        #======================Function Button=============

    #============================Login only for admin======================
    def login(self):
            self.root=root
            self.root.geometry("1280x600+0+0")    #1280 X 600 is screen resolution and for start from corner used 0+0
            self.root.title("Admin Login")

        #===========background image========
            login_img=Image.open(r"C:\Users\user\Desktop\Face Reconization System\Images\login-bg2.jpg")
            login_img=login_img.resize((1280,600),Image.LANCZOS)
            self.photologin_img=ImageTk.PhotoImage(login_img)

            bg_img=Label(self.root,image=self.photologin_img)
            bg_img.place(x=0,y=0,width=1280,height=600)

            login_frame=Frame(bg_img,bd=2, bg="black")
            login_frame.place(x=500,y=100,width=300, height=420)


            login_label=Label(login_frame,text="Admin Login",font=("times new roman",26,"bold"),bg="black",fg="green")
            login_label.place(x=50,y=5)
            

            username_label=Label(login_frame,text="User Name",font=("times new roman",16,"bold"),bg="black",fg="red")
            username_label.place(x=10,y=100)

            self.username_entry=ttk.Entry(login_frame,width=15,font=("times new roman",16,"bold"))
            self.username_entry.place(x=120,y=100)

            password_label=Label(login_frame,text="Password",font=("times new roman",16,"bold"),bg="black",fg="red")
            password_label.place(x=10,y=200)

            self.password_entry=ttk.Entry(login_frame,show="•",font=15)
            self.password_entry.place(x=120,y=200)

            #login button
            b1=Button(login_frame,text="Login",command=self.validate_login,cursor="hand2",font=("times new roman",16,"bold"),bg="green",fg="yellow")
            b1.place(x=80,y=300,width=80,height=40)

            #Back To main Screen
            back=Button(login_frame,text="Back",command=self.back_to_home,cursor="hand2",font=("times new roman",16,"bold"),bg="green",fg="yellow")
            back.place(x=200,y=300,width=80,height=40)


    #=================validate Login==============
    def validate_login(self):
            username = self.username_entry.get()
            password = self.password_entry.get()

             
        
        # Connect to MySQL database
            try:
                conn = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="face_recognizer"
                )
            
                cursor = conn.cursor()
            
            # Query to fetch user details
                query = "SELECT * FROM login WHERE username = %s AND password = %s"
                cursor.execute(query, (username, password))
            
            # Fetch result
                result = cursor.fetchone()
            
                if result:
                    b1=Button(self.root,text="Welcome Admin",command=self.student_details,cursor="hand2",font=("times new roman",16,"bold"),bg="green",fg="yellow")
                    b1.place(x=560,y=470,width=200,height=40)
                    
                else:
                    messagebox.showerror("Error", "Please Enter valid Credentials")
                
            # Close the cursor and connection
                cursor.close()
                conn.close()
            
            except mysql.connector.Error as e:
                messagebox.showerror("Error", f"Error connecting to MySQL database: {e}")

#===========Back To Home Screen==============
    def back_to_home(self):
        self.root.destroy()  # Close the current window
        root = Tk()  # Create a new instance of Tk
        Face_Recognisation_System(root)  # Reinitialize the home screen
        root.mainloop()  # Start the main loop for the new instance

#=========Its open new window after login
    def student_details(self):
        self.new_window=Toplevel(self.root)
        self.app=Student(self.new_window)

#==========for open images========
    def open_img(self):
         os.startfile("data")

#=============Train Photos=============
    def train_classifier(self):
         data_dir=("data")
         path=[os.path.join(data_dir,file) for file  in os.listdir(data_dir)] # list comprehensive

         faces=[]
         ids=[]

         for image in path:
              img=Image.open(image).convert("L") #Gray Scale image
              imageNp=np.array(img,'uint8')  #uint is datatype
              id=int(os.path.split(image)[1].split('.')[1])

              faces.append(imageNp)
              ids.append(id)
              cv2.imshow("Training",imageNp)
              cv2.waitKey(1)==13
         ids=np.array(ids)

         #==============Train the classifier============
         clf=cv2.face.LBPHFaceRecognizer_create()                          # Face.LBPHFaceRecognizer_create()
         clf.train(faces,ids)
         clf.write("Classifier.xml")
         cv2.destroyAllWindows()
         messagebox.showwarning("Result","Training Dataset completed")



    def face_data(self):
        self.new_window=Toplevel(self.root)
        self.app=Face_recognition(self.new_window)

    def show_Attendance1(self):
        self.new_window=Toplevel(self.root)
        self.app=Attendance(self.new_window)

    def show_help(self):
        help_window = Toplevel(self.root)
        help_window.title("Help")
        help_window.geometry("500x600+400+200")

        help_text = """
        Welcome to the Face Recognition System!

        Instructions:
        1. Student Details: Add and manage student information.
        2. Face Detector: Detect faces and register them in the system.
        3. Attendance: Mark attendance using face recognition.
        4. Train Face: Train the system with new faces.
        5. Photos: View and manage the photos used for face recognition.
        6. Help: View help information and contact support.

        For support, contact:
        Email 1: vikasbargal2134@gmail.com
        Email 2: pravinpadul01@gmail.com
        Phone 1: 9405143751
        Phone 2: 8483897278
        """

        help_label = Label(help_window, text=help_text, font=("times new roman", 12), justify=LEFT)
        help_label.pack(pady=20, padx=20)

        close_button = Button(help_window, text="Close", command=help_window.destroy, font=("times new roman", 12, "bold"), bg="red", fg="white")
        close_button.pack(pady=10)

#===========For exit the system========
    def exit_application(self):
        self.root.destroy()

    

    





if __name__=="__main__":
    root =Tk()
    obj=Face_Recognisation_System(root)
    root.mainloop()


